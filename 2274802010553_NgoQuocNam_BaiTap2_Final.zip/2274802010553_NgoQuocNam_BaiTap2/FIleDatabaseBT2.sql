SELECT * FROM public.users
ORDER BY user_id ASC