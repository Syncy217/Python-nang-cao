import tkinter as tk
from tkinter import ttk
from database import Database
from functions import UserManagement
from tkinter import messagebox


class UserManagementApp:
    def __init__(self, win):
        self.win = win
        self.win.title("Hệ Thống Quản Lý Người Dùng")

        self.db = Database()  # Tạo đối tượng Database
        self.user_management = UserManagement(self.db)  # Tạo đối tượng UserManagement

        self.create_login_page()  # Gọi hàm tạo trang đăng nhập

    # Tạo trang đăng nhập
    def create_login_page(self):
        self.login_frame = ttk.Frame(self.win, padding="20")
        self.login_frame.pack(fill=tk.BOTH, expand=True)

        # Nhập thông tin kết nối
        self.create_connection_inputs()

        # Nút Đăng nhập
        login_button = ttk.Button(self.login_frame, text="Đăng nhập", command=self.connect_to_db)
        login_button.grid(row=5, column=0, columnspan=2, pady=15, sticky=tk.EW)

    # Nhập thông tin kết nối
    def create_connection_inputs(self):
        style = ttk.Style()
        style.configure("TLabel", font=("Arial", 10))
        style.configure("TButton", font=("Arial", 10))
        style.configure("TEntry", font=("Arial", 10))

        # Host
        ttk.Label(self.login_frame, text="Host:").grid(row=0, column=0, padx=5, pady=5, sticky=tk.W)
        self.entry_host = ttk.Entry(self.login_frame)
        self.entry_host.grid(row=0, column=1, padx=5, pady=5, sticky=tk.EW)
        self.entry_host.insert(0, "localhost")  # Giá trị mặc định cho Host

        # Database
        ttk.Label(self.login_frame, text="Database:").grid(row=1, column=0, padx=5, pady=5, sticky=tk.W)
        self.entry_database = ttk.Entry(self.login_frame)
        self.entry_database.grid(row=1, column=1, padx=5, pady=5, sticky=tk.EW)

        # Username
        ttk.Label(self.login_frame, text="Username:").grid(row=2, column=0, padx=5, pady=5, sticky=tk.W)
        self.entry_user = ttk.Entry(self.login_frame)
        self.entry_user.grid(row=2, column=1, padx=5, pady=5, sticky=tk.EW)
        self.entry_user.insert(0, "postgres")  # Giá trị mặc định cho Username

        # Password
        ttk.Label(self.login_frame, text="Password:").grid(row=3, column=0, padx=5, pady=5, sticky=tk.W)
        self.entry_password = ttk.Entry(self.login_frame, show="*")
        self.entry_password.grid(row=3, column=1, padx=5, pady=5, sticky=tk.EW)

        # Port
        ttk.Label(self.login_frame, text="Port:").grid(row=4, column=0, padx=5, pady=5, sticky=tk.W)
        self.entry_port = ttk.Entry(self.login_frame)
        self.entry_port.grid(row=4, column=1, padx=5, pady=5, sticky=tk.EW)
        self.entry_port.insert(0, "5432")  # Giá trị mặc định cho Port

    # Kết nối đến cơ sở dữ liệu và hiển thị trang admin
    def connect_to_db(self):
        host = self.entry_host.get()
        database = self.entry_database.get()
        user = self.entry_user.get()
        password = self.entry_password.get()
        port = self.entry_port.get()

        connection = self.db.connect(host, database, user, password, port)
        if connection:
            self.show_admin_page()  # Gọi hàm hiển thị trang quản trị nếu kết nối thành công

    # Hiển thị trang quản trị
    def show_admin_page(self):
        self.login_frame.pack_forget()  # Ẩn khung đăng nhập
        admin_frame = ttk.Frame(self.win, padding="20")
        admin_frame.pack(fill=tk.BOTH, expand=True)

        ttk.Label(admin_frame, text="Chào Mừng Đến Trang Quản Trị!", font=("Arial", 14, "bold")).pack(pady=10)

        # TreeView cho người dùng
        self.list_widget = ttk.Treeview(admin_frame, columns=('ID', 'Tên', 'Mật khẩu', 'Vai trò'), show='headings', height=10)
        self.list_widget.heading('ID', text='ID')  # Đặt tiêu đề cho cột ID
        self.list_widget.heading('Tên', text='Tên')  # Đặt tiêu đề cho cột Tên
        self.list_widget.heading('Mật khẩu', text='Mật khẩu')  # Đặt tiêu đề cho cột Mật khẩu
        self.list_widget.heading('Vai trò', text='Vai trò')  # Đặt tiêu đề cho cột Vai trò
        self.list_widget.column('ID', width=50, anchor=tk.CENTER)
        self.list_widget.column('Tên', width=150, anchor=tk.W)
        self.list_widget.column('Mật khẩu', width=150, anchor=tk.W)
        self.list_widget.column('Vai trò', width=100, anchor=tk.CENTER)
        self.list_widget.pack(pady=10, fill=tk.BOTH, expand=True)

        # Tải lại dữ liệu
        self.user_management.reload_table('users', self.list_widget)  # Tải lại bảng người dùng

        # Khung nhập liệu cho người dùng mới
        self.create_user_input_frame(admin_frame)

    # Tạo khung nhập liệu cho người dùng mới
    def create_user_input_frame(self, parent):
        input_frame = ttk.Frame(parent)
        input_frame.pack(pady=10)

        # Nhập tên người dùng
        ttk.Label(input_frame, text="Tên người dùng:").grid(row=0, column=0, padx=5, pady=5, sticky=tk.W)
        self.entry_username = ttk.Entry(input_frame)
        self.entry_username.grid(row=0, column=1, padx=5, pady=5, sticky=tk.EW)

        # Nhập mật khẩu
        ttk.Label(input_frame, text="Mật khẩu:").grid(row=1, column=0, padx=5, pady=5, sticky=tk.W)
        self.entry_password_new = ttk.Entry(input_frame, show="*")
        self.entry_password_new.grid(row=1, column=1, padx=5, pady=5, sticky=tk.EW)

        # Nhập vai trò
        ttk.Label(input_frame, text="Vai trò:").grid(row=2, column=0, padx=5, pady=5, sticky=tk.W)
        self.entry_role = ttk.Entry(input_frame)
        self.entry_role.grid(row=2, column=1, padx=5, pady=5, sticky=tk.EW)

        # Nút Thêm người dùng
        add_button = ttk.Button(input_frame, text="Thêm người dùng", command=self.add_user)
        add_button.grid(row=3, column=0, columnspan=2, pady=5, sticky=tk.EW)

        # Nút Xóa người dùng
        delete_button = ttk.Button(input_frame, text="Xóa người dùng", command=self.delete_user)
        delete_button.grid(row=4, column=0, columnspan=2, pady=5, sticky=tk.EW)

        # Nút Cập nhật người dùng
        update_button = ttk.Button(input_frame, text="Cập nhật người dùng", command=self.update_user)
        update_button.grid(row=5, column=0, columnspan=2, pady=5, sticky=tk.EW)

    # Thêm người dùng mới
    def add_user(self):
        username = self.entry_username.get()
        password = self.entry_password_new.get()
        role = self.entry_role.get()
        self.user_management.add_user(username, password, role, self.list_widget)

    # Xóa người dùng đã chọn
    def delete_user(self):
        selected_item = self.list_widget.selection()
        if selected_item:
            user_id = self.list_widget.item(selected_item, 'values')[0]
            username = self.list_widget.item(selected_item, 'values')[1]
            self.user_management.delete_user(username, self.list_widget)
        else:
            messagebox.showwarning("Cảnh báo", "Vui lòng chọn người dùng để xóa.")

    # Cập nhật thông tin người dùng đã chọn
    def update_user(self):
        selected_item = self.list_widget.selection()
        if selected_item:
            user_id = self.list_widget.item(selected_item, 'values')[0]
            new_username = self.entry_username.get()
            new_password = self.entry_password_new.get()
            new_role = self.entry_role.get()
            self.user_management.update_user(user_id, new_username, new_password, new_role, self.list_widget)
        else:
            messagebox.showwarning("Cảnh báo", "Vui lòng chọn người dùng để cập nhật.")


if __name__ == "__main__":
    win = tk.Tk()
    app = UserManagementApp(win)
    win.mainloop()
